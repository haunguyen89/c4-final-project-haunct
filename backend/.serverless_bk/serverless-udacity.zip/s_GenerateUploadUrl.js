
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'hoangthien99',
  applicationName: 'serverless-udacity',
  appUid: '59QtS5knL28TjmLjfF',
  orgUid: 'e1d1a038-8cf1-450d-a3e2-4a56a509bf40',
  deploymentUid: '919ad768-d980-4977-acc0-87bd942a97f6',
  serviceName: 'serverless-udacity',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udacity-dev-GenerateUploadUrl', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/generateUploadUrl.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}